namespace pbaweja1BAIS3150CodeSample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddRazorPages();// this basically add services to the container



            var app = builder.Build();

            //configure http request pipeline
            app.UseStaticFiles();// add for wwwroot -- htmlpages are static files, htmlpages go under wwwroot
            app.UseRouting();//
            app.MapRazorPages();//for using razor pages
            app.Run();
        }
    }
}