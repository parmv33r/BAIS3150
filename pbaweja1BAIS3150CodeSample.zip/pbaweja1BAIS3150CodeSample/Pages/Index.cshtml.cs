using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
