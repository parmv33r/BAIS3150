﻿namespace pbaweja1BAIS3150CodeSample.Domain
{
    public class Student
    {
        // string.empty (defualt non-null vlue oif object require before setting)
        // ? nullable reference type
        private string _studentID = string.Empty; // camel case proceeded wth the underscore _
        private string _firstname = "";//*********** other way of string.Empty **String is same as ""

        public string StudentID//Pascal case
        {
            get
            {
                return _studentID;
            }
            set
            {
                _studentID = value;
            }
        }

        public string FirstName //expression-bodies property accessors
        {
            get => _firstname; //implementation can be made of only a single statement (diff. ways of coding)
            set => _firstname = value;
        }
        public string LastName { get; set; } = string.Empty; //auto-implemented property, no logic in set/get

        public string? Email { get; set; }//there might be null values for email that is hy we used question mark ?


        public Student()
        {
            //contructor logic

        }
    }
}
