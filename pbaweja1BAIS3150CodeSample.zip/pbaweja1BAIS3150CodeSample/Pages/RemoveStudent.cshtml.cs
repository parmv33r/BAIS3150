using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class RemoveStudentModel : PageModel
    {
        [BindProperty]
        public string StudentId { get; set; }

        public string Message { get; set; }
        public string ErrorMessage { get; set; }

        public void OnGet()
        {
        }

        public void OnPost()
        {

            try
            {
                BCS RequestedDriver = new BCS();
                bool confirmation;

                Student student = new Student();

                student = RequestedDriver.FindStudent(StudentId);

                if (student != null)
                {
                    confirmation = RequestedDriver.RemoveStudent(StudentId);

                    if (confirmation)
                    {
                        Message = $"Student with {StudentId} has been removed.";
                    }

                }

                else
                {
                    ErrorMessage = $"Student with ID: {StudentId} does not exist. Please check your input again.";
                }

                
            }
            catch (SqlException ex)
            {
                ErrorMessage = ex.Message;
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }

        }
    }
}
