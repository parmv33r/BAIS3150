﻿using System.Data;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;

namespace pbaweja1BAIS3150CodeSample.Technical_Services
{
    public class Programs
    {
        public bool AddProgram(string programCode, string description)
        {
            bool succeeded = false;

            //establish connection
            SqlConnection MyDataSource; //decalration
            MyDataSource = new SqlConnection(); //instantiation
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand AddProgramCommand = new SqlCommand(); //declare and instantiate
            AddProgramCommand.Connection = MyDataSource;
            AddProgramCommand.CommandType = CommandType.StoredProcedure;
            AddProgramCommand.CommandText = "AddProgram";

            SqlParameter AddProgramCommandParameter;

            AddProgramCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@ProgramCode",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = programCode
            };

            AddProgramCommand.Parameters.Add(AddProgramCommandParameter);

            AddProgramCommandParameter = new SqlParameter
            {
                ParameterName = "@Description",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = description
            };

            AddProgramCommand.Parameters.Add(AddProgramCommandParameter);

            AddProgramCommand.ExecuteNonQuery();
            MyDataSource.Close();
            Console.WriteLine($"Success - Program Added Successfully");
            foreach (SqlParameter param in AddProgramCommand.Parameters)
            {
                Console.WriteLine($"{param.ParameterName}: {param.Value}");
            }
            succeeded = true;
            return succeeded;
        }

        public Domain.Program GetProgram(string programCode)
        {
            Domain.Program program = null;

            SqlConnection MyDataSource = new SqlConnection();
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand GetProgramsCommand = new SqlCommand()
            {
                Connection = MyDataSource,
                CommandType = CommandType.StoredProcedure,
                CommandText = "GetProgram"
            };

            SqlParameter GetProgramCommandParameter;

            GetProgramCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@ProgramCode",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = programCode
            };

            GetProgramsCommand.Parameters.Add(GetProgramCommandParameter);

            using (SqlDataReader reader = GetProgramsCommand.ExecuteReader())
            {

                if (reader.Read())
                {
                    program = new Domain.Program
                    {
                        ProgramCode = reader["ProgramCode"].ToString(),
                        Description = reader["Description"].ToString()
                    };
                }

            }

            GetProgramsCommand.ExecuteNonQuery();
            MyDataSource.Close();
            return program;
        }

        public List<Domain.Program> GetProgramList()
        {
            List<Domain.Program> programs = new List<Domain.Program>();

            SqlConnection MyDataSource = new SqlConnection();
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand GetProgramsCommand = new SqlCommand()
            {
                Connection = MyDataSource,
                CommandType = CommandType.StoredProcedure,
                CommandText = "GetPrograms"
            };

            SqlDataReader GetProgramsDataReader;
            GetProgramsDataReader = GetProgramsCommand.ExecuteReader();

            if (GetProgramsDataReader.HasRows)
            {

                while (GetProgramsDataReader.Read())
                {
                    Domain.Program program = new Domain.Program
                    {
                        ProgramCode = GetProgramsDataReader.GetString(GetProgramsDataReader.GetOrdinal("ProgramCode")),
                        Description = GetProgramsDataReader.GetString(GetProgramsDataReader.GetOrdinal("Description")),
                    };

                    programs.Add(program);
                }
            }

            GetProgramsDataReader.Close();
            MyDataSource.Close();

            return programs;
        }
    }
}
