using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class FindProgramModel : PageModel
    {
        [BindProperty]
        public string ProgramCode { get; set; }

        public string Message { get; set; }
        public string ErrorMessage { get; set; }

        public List <Student> studentlist { get; set; } = new List<Student>();

        public bool FormSubmitted { get; set; }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            try
            {
                BCS RequestedDriver = new();

                Domain.Program programFound;

                programFound = RequestedDriver.FindProgram(ProgramCode);

                if(programFound!=null)
                {
                    if(programFound.EnrolledStudents.Count > 0)
                    {
                        Message = $"Number of students enrolled in the {programFound.ProgramCode} program.: {programFound.EnrolledStudents.Count}";

                        foreach (var existingStudent in programFound.EnrolledStudents)
                        {
                            studentlist.Add(existingStudent);
                        }
                    }

                    else
                    {
                        Message = $"No Students are enrolled in {programFound.ProgramCode} yet!";
                    }
                }

                else
                {
                    ErrorMessage = $"Program with Code: {ProgramCode} not found";
                }
            }
            catch (SqlException ex)
            {
                ErrorMessage = ex.Message;

            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
        }
    }
}
