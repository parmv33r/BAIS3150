﻿namespace pbaweja1BAIS3150CodeSample.Domain
{
    public class Program
    {
        public string ProgramCode { get; set; }
        public string Description { get; set; }

        public List<Student> EnrolledStudents { get; }
        public Program()
        {
            EnrolledStudents = new List<Student>();
        }
    }
}
