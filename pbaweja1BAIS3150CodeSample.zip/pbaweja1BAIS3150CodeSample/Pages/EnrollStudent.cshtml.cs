using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class EnrollStudentModel : PageModel
    {
        [BindProperty]
        public string StudentId { get; set; }

        [BindProperty]
        public string FirstName { get; set; }

        [BindProperty]
        public string LastName { get; set; }

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string ProgramCode { get; set; }

        public List<Domain.Program> programs { get; set; }

        public string Message { get; set; }
        public string ErrorMessage { get; set; }

        public void OnGet()
        {
            BCS RequestedManager = new BCS();

            programs = RequestedManager.GetProgramList();

        }
        public void OnPost()
        {
            try 
            { 
                BCS RequestedDriver = new BCS();
                Student student = new Student();
                bool confirmation;
                student.StudentID = StudentId;
                student.FirstName = FirstName;
                student.LastName = LastName;
                if(!string.IsNullOrEmpty(Email))
                {
                    student.Email = Email;
                }
                else
                {
                    student.Email = "";
                }

                programs = RequestedDriver.GetProgramList();
                confirmation = RequestedDriver.EnrolStudent(student, ProgramCode);

                if (confirmation)
                {
                    Message = $"Student Added in {ProgramCode}: ID: {StudentId} - {FirstName}, {LastName}";
                }

            }

            catch (SqlException ex)
            {
                // Pass the exception message to the view
                ErrorMessage = ex.Message;

            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;

            }

        }
    }
}
