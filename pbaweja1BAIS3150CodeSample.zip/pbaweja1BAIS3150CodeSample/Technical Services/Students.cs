﻿using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;
using System.Data;

namespace pbaweja1BAIS3150CodeSample.Technical_Services
{
    public class Students
    {
        public bool AddStudent(Student acceptedStudent, string programCode)// parameter, camel case
        {
            bool Success = false;

            SqlConnection MyDataSource = new();
            MyDataSource.ConnectionString = @"Persist Security Info=False;Database=pbaweja1;User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca;";
            MyDataSource.Open();

            SqlCommand AddStudentCommand = new()
            {
                Connection = MyDataSource,
                CommandType = System.Data.CommandType.StoredProcedure,
                CommandText = "AddStudent"
            };
            SqlParameter AddStudentCommandParameter;

            AddStudentCommandParameter = new()
            {
                ParameterName = "@StudentID",
                SqlDbType = System.Data.SqlDbType.VarChar,
                Direction = System.Data.ParameterDirection.Input,
                SqlValue = acceptedStudent.StudentID
            };
            AddStudentCommand.Parameters.Add(AddStudentCommandParameter);

            AddStudentCommandParameter = new()
            {
                ParameterName = "@FirstName",
                SqlDbType = System.Data.SqlDbType.VarChar,
                Direction = System.Data.ParameterDirection.Input,
                SqlValue = acceptedStudent.FirstName
            };
            AddStudentCommand.Parameters.Add(AddStudentCommandParameter);

            AddStudentCommandParameter = new()
            {
                ParameterName = "@LastName",
                SqlDbType = System.Data.SqlDbType.VarChar,
                Direction = System.Data.ParameterDirection.Input,
                SqlValue = acceptedStudent.LastName
            };
            AddStudentCommand.Parameters.Add(AddStudentCommandParameter);

            AddStudentCommandParameter = new()
            {
                ParameterName = "@Email",
                SqlDbType = System.Data.SqlDbType.VarChar,
                Direction = System.Data.ParameterDirection.Input,
                SqlValue = acceptedStudent.Email
            };

            AddStudentCommand.Parameters.Add(AddStudentCommandParameter);

            AddStudentCommandParameter = new()
            {
                ParameterName = "@ProgramCode",
                SqlDbType = System.Data.SqlDbType.VarChar,
                Direction = System.Data.ParameterDirection.Input,
                SqlValue = programCode
            };
            AddStudentCommand.Parameters.Add(AddStudentCommandParameter);
            // ExampleCommand.Parameters.Add(ExampleCommandParameter);//add parameters 2 to the commands

            AddStudentCommand.ExecuteNonQuery();//execute the cmmand
            MyDataSource.Close();//close the connection


            Success = true;
            if (Success == true)
            {
                Console.WriteLine($"New Student has been added to {programCode}");
                string fullName = $"{acceptedStudent.FirstName} {acceptedStudent.LastName}";
                Console.WriteLine(fullName);
            }
            return Success;

        }

        public Student GetStudent(string studentID)
        {
            Student student = null;

            //establish connection
            SqlConnection MyDataSource; //decalration
            MyDataSource = new SqlConnection(); //instantiation
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand GetStudentCommand = new SqlCommand(); //declare and instantiate
            GetStudentCommand.Connection = MyDataSource;
            GetStudentCommand.CommandType = CommandType.StoredProcedure;
            GetStudentCommand.CommandText = "GetStudent";

            SqlParameter GetStudentCommandParameter;

            GetStudentCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@StudentID",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = studentID
            };

            GetStudentCommand.Parameters.Add(GetStudentCommandParameter);

            using (SqlDataReader reader = GetStudentCommand.ExecuteReader())
            {
                if (reader.Read())
                {
                    student = new Student
                    {
                        StudentID = reader["StudentID"].ToString(),
                        FirstName = reader["FirstName"].ToString(),
                        LastName = reader["LastName"].ToString(),
                        Email = reader["Email"].ToString()
                    };
                }
            }

            return student;
        }

        public bool UpdateStudent(Student enrolledStudent)
        {
            bool success = false;

            //establish connection
            SqlConnection MyDataSource; //declaration
            MyDataSource = new SqlConnection(); //instantiation
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand UpdateStudentCommand = new SqlCommand(); //declare and instantiate
            UpdateStudentCommand.Connection = MyDataSource;
            UpdateStudentCommand.CommandType = CommandType.StoredProcedure;
            UpdateStudentCommand.CommandText = "UpdateStudent";

            SqlParameter UpdateStudentCommandParameter;

            UpdateStudentCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@StudentID",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = enrolledStudent.StudentID
            };

            UpdateStudentCommand.Parameters.Add(UpdateStudentCommandParameter);

            UpdateStudentCommandParameter = new SqlParameter
            {
                ParameterName = "@FirstName",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = enrolledStudent.FirstName
            };

            UpdateStudentCommand.Parameters.Add(UpdateStudentCommandParameter);


            UpdateStudentCommandParameter = new SqlParameter
            {
                ParameterName = "@LastName",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = enrolledStudent.LastName
            };

            UpdateStudentCommand.Parameters.Add(UpdateStudentCommandParameter);


            UpdateStudentCommandParameter = new SqlParameter
            {
                ParameterName = "@Email",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = enrolledStudent.Email
            };

            UpdateStudentCommand.Parameters.Add(UpdateStudentCommandParameter);

            UpdateStudentCommand.ExecuteNonQuery();
            MyDataSource.Close();

            Console.WriteLine($"Success - Student Updated");
            foreach (SqlParameter param in UpdateStudentCommand.Parameters)
            {
                Console.WriteLine($"{param.ParameterName}: {param.Value}");
            }

            return success = true;
        }

        public bool DeleteStudent(string studentID)
        {
            bool success = false;

            //establish connection
            SqlConnection MyDataSource; //decalration
            MyDataSource = new SqlConnection(); //instantiation
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand DeleteStudentCommand = new SqlCommand(); //declare and instantiate
            DeleteStudentCommand.Connection = MyDataSource;
            DeleteStudentCommand.CommandType = CommandType.StoredProcedure;
            DeleteStudentCommand.CommandText = "DeleteStudent";

            SqlParameter DeleteStudentCommandParameter;

            DeleteStudentCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@StudentID",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = studentID
            };

            DeleteStudentCommand.Parameters.Add(DeleteStudentCommandParameter);

            DeleteStudentCommand.ExecuteNonQuery();
            MyDataSource.Close();

            Console.WriteLine($"Success - Student with ID: {studentID} is deleted.");

            return success = true;

        }

        public List<Student> GetStudents(string programCode)
        {
            List<Student> enrolledStudents = new List<Student>();

            SqlConnection MyDataSource = new SqlConnection();
            MyDataSource.ConnectionString = @"Persist Security Info=False; Database=pbaweja1; User ID=pbaweja1;Password=NewData#07;server=dev1.baist.ca; TrustServerCertificate=true;";
            MyDataSource.Open();

            SqlCommand GetStudentsByProgramCommand = new SqlCommand()
            {
                Connection = MyDataSource,
                CommandType = CommandType.StoredProcedure,
                CommandText = "GetStudentsByProgram"
            };

            SqlParameter GetStudentsByProgramCommandParameter;

            GetStudentsByProgramCommandParameter = new SqlParameter //object initialization syntax
            {
                ParameterName = "@ProgramCode",
                SqlDbType = SqlDbType.VarChar,
                Direction = ParameterDirection.Input,
                SqlValue = programCode
            };

            GetStudentsByProgramCommand.Parameters.Add(GetStudentsByProgramCommandParameter);

            SqlDataReader GetStudentsByProgramDataReader;
            GetStudentsByProgramDataReader = GetStudentsByProgramCommand.ExecuteReader();

            if (GetStudentsByProgramDataReader.HasRows)
            {

                while (GetStudentsByProgramDataReader.Read())
                {
                    Student student = new Student
                    {
                        StudentID = GetStudentsByProgramDataReader.GetString(GetStudentsByProgramDataReader.GetOrdinal("StudentID")),
                        FirstName = GetStudentsByProgramDataReader.GetString(GetStudentsByProgramDataReader.GetOrdinal("FirstName")),
                        LastName = GetStudentsByProgramDataReader.GetString(GetStudentsByProgramDataReader.GetOrdinal("LastName")),
                        Email = GetStudentsByProgramDataReader.GetString(GetStudentsByProgramDataReader.GetOrdinal("Email"))
                    };

                    enrolledStudents.Add(student);
                }
            }

            GetStudentsByProgramDataReader.Close();
            MyDataSource.Close();

            return enrolledStudents;

        }
    }
}
