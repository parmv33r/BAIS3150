﻿using pbaweja1BAIS3150CodeSample.Technical_Services;

namespace pbaweja1BAIS3150CodeSample.Domain
{
    internal class BCS
    {
        public bool EnrolStudent(Student acceptedStudent, string programCode)
        {
            bool confirmation;

            Students StudentManager = new();

            confirmation = StudentManager.AddStudent(acceptedStudent, programCode);

            return confirmation;
        }

        public bool CreateProgram(string programCode, string description)
        {
            bool confirmation;

            Programs BCSProgramManager = new();

            confirmation = BCSProgramManager.AddProgram(programCode, description);

            return confirmation;
        }

        public Student FindStudent(string studentId)
        {
            Students StudentManager = new();

            Student StudentFound = new();

            StudentFound = StudentManager.GetStudent(studentId);

            return StudentFound;

        }

        public bool ModifyStudent(Student enrolledStudent)
        {
            bool confirmation;

            Students StudentManager = new();

            confirmation = StudentManager.UpdateStudent(enrolledStudent);

            return confirmation;
        }

        public bool RemoveStudent(string studentId)
        {
            bool confirmation;

            Students StudentManager = new();

            confirmation = StudentManager.DeleteStudent(studentId);

            return confirmation;
        }

        public Program FindProgram(string ProgramCode)
        {
            Programs ProgramManager = new();

            Students StudentManger = new();

            Program ProgramFound = new();

            List<Student> studentsfound = new();

            ProgramFound = ProgramManager.GetProgram(ProgramCode);

            studentsfound = StudentManger.GetStudents(ProgramCode);

            foreach (Student student in studentsfound)
            {
                ProgramFound.EnrolledStudents.Add(student);
            }

            return ProgramFound;
        }

        public List<Domain.Program> GetProgramList()
        {
            Programs ProgramManager = new();

            List<Domain.Program> programs = new();

            programs = ProgramManager.GetProgramList();

            return programs;
        }
    }
}
