using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class ModifyStudentModel : PageModel
    {
        [BindProperty]
        public string StudentId { get; set; }

        [BindProperty]
        public string FirstName { get; set; }

        [BindProperty]
        public string LastName { get; set; }

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string ProgramCode { get; set; }

        public List<Domain.Program> programs { get; set; }

        public string Message { get; set; }
        public string ErrorMessage { get; set; }


        public void OnGet()
        {
        }

        public void OnPost()
        {
           
                if (!string.IsNullOrEmpty(Request.Form["searchButton"]))
                {
                    // Handle the search form submission
                    OnPostSearch();
                }
                else if (!string.IsNullOrEmpty(Request.Form["submitButton"]))
                {
                    OnPostSubmit();
                }

        }

        public void OnPostSearch()
        {
            try
            {
                BCS RequestedDriver = new BCS();

                Student student = new Student();

                student = RequestedDriver.FindStudent(StudentId);

                if (student != null)
                {
                    Message = $"Student Found!!";

                    FirstName = student.FirstName;
                    LastName = student.LastName;
                    Email = student.Email;
                }

                else
                {
                    ErrorMessage = $"Student with ID: {StudentId} does not exist. Please check your input again.";
                }
            }

            catch (SqlException ex)
            {
                ErrorMessage = ex.Message;
            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;

            }
        }

        public void OnPostSubmit()
        {
            try
            {
                BCS RequestedDriver = new BCS();
                Student newStudent = new();
                bool confirmation;
                newStudent.StudentID = StudentId;
                newStudent.FirstName = FirstName;
                newStudent.LastName = LastName;
                newStudent.Email = Email;

                confirmation = RequestedDriver.ModifyStudent(newStudent);

                if (confirmation)
                {
                    Message = "Student Info updated!!";

                }

                else
                {
                    ErrorMessage = "Something went wrong. Student info not updated.";
                }
            }

            catch (SqlException ex)
            {
                ErrorMessage = ex.Message;
            }

            catch (Exception ex)
            {
                ErrorMessage = ex.Message;

            }
        }
    }
}
