using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;
using System;
using System.ComponentModel.DataAnnotations;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class CreateProgramModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "Program Code is required")]
        [MaxLength(10, ErrorMessage = "Program Code must be at most 10 characters")]
        public string ProgramCode { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Description is required")]
        [MaxLength(60, ErrorMessage = "Description must be at most 60 characters")]
        public string Description { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }

        

        public void OnGet()
        {

        }

        public void OnPost()
        {
            try
            {
                BCS RequestedDriver = new();
                bool confirmation;
                confirmation = RequestedDriver.CreateProgram(ProgramCode, Description);

                if (confirmation)
                {
                    Message = $"Program Created: {ProgramCode} - {Description}";
                }

            }

            catch (SqlException ex)
            {
                // Pass the exception message to the view
                ErrorMessage = ex.Message;

            }

        }
    }
}
