using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;
using System;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class CreateProgramModel : PageModel
    {
        [BindProperty]
        public string ProgramCode { get; set; }
        [BindProperty]
        public string Description { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }

        

        public void OnGet()
        {

        }

        public void OnPost()
        {
            try
            {
                BCS RequestedDriver = new();
                bool confirmation;
                confirmation = RequestedDriver.CreateProgram(ProgramCode, Description);

                if (confirmation)
                {
                    Message = $"Program Created: {ProgramCode} - {Description}";
                }

            }

            catch (SqlException ex)
            {
                // Pass the exception message to the view
                ErrorMessage = ex.Message;

            }

        }
    }
}
