using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using pbaweja1BAIS3150CodeSample.Domain;

namespace pbaweja1BAIS3150CodeSample.Pages
{
    public class FindStudentModel : PageModel
    {
        [BindProperty]
        public string StudentId { get; set; }

        public string Message { get; set; }
        public string ErrorMessage { get; set; }
        public void OnGet()
        {

        }

        public void OnPost()
        {

            try
            {
                BCS RequestedDriver = new BCS();

                Student student = new Student();

                student = RequestedDriver.FindStudent(StudentId);

                if (student != null)
                {
                    Message = $"Student Found!!\n\n Name: {student.FirstName}, {student.LastName} \n Email: {student.Email} ";
                }

                else
                {
                    ErrorMessage = $"Student with ID: {StudentId} does not exist. Please check your input again.";
                }
            }

            catch (SqlException ex)
            {
                ErrorMessage = ex.Message;
            }

            catch(Exception ex)
            {
                ErrorMessage = ex.Message;

            }

        }
    }
}
